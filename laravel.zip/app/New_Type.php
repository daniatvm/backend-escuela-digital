<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class New_Type extends Model
{
    protected $table = 'new_type';
    protected $guarded=['id_new_type'];
}
